<?php
require_once 'includes/auth.php';
$isLoggedIn = isLoggedIn();
$isAdmin = $isLoggedIn && isAdmin();
$current_page = basename($_SERVER['PHP_SELF']);

if ($isLoggedIn) {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $dbBalance = $stmt->fetchColumn();
        if ($dbBalance !== false) {
            $_SESSION['balance'] = (float)$dbBalance;
        }
    } catch (Exception $e) {
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : SITE_NAME . ' ' . SITE_SUBTITLE; ?></title>

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        darkMode: 'class',
        theme: {
          extend: {
            colors: {
              brand: {
                primary: 'rgb(var(--brand-primary-rgb))',
                secondary: 'rgb(var(--brand-secondary-rgb))',
                bg: 'rgb(var(--brand-bg-rgb))',
                surface: 'rgb(var(--brand-surface-rgb))',
                border: 'rgb(var(--brand-border-rgb))',
                text: 'rgb(var(--brand-text-rgb))',
                muted: 'rgb(var(--brand-muted-rgb))',
                success: '#10b981',
                warning: '#f59e0b',
                error: '#ef4444'
              }
            },
            fontFamily: {
              sans: ['Inter', 'sans-serif'],
            },
            boxShadow: {
              glow: '0 0 15px rgba(99, 102, 241, 0.15)',
              'glow-cyan': '0 0 15px rgba(6, 182, 212, 0.15)'
            }
          }
        }
      }
    </script>
    <style type="text/tailwindcss">
      :root {
        --brand-primary-rgb: 99 102 241;
        --brand-secondary-rgb: 6 182 212;
        --brand-bg-rgb: 226 232 240;
        --brand-surface-rgb: 248 250 252;
        --brand-border-rgb: 148 163 184;
        --brand-text-rgb: 15 23 42;
        --brand-muted-rgb: 71 85 105;
      }

      .dark {
        --brand-bg-rgb: 9 9 11;
        --brand-surface-rgb: 24 24 27;
        --brand-border-rgb: 39 39 42;
        --brand-text-rgb: 250 250 250;
        --brand-muted-rgb: 161 161 170;
      }

      .glass-panel {
        background-color: var(--brand-surface);
        border: 1px solid var(--brand-border);
        backdrop-filter: blur(12px);
      }

      .glass-card {
        background-color: rgb(var(--brand-surface-rgb));
        border: 1px solid rgb(var(--brand-border-rgb));
        backdrop-filter: blur(8px);
        box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.08);
      }

      .dark .glass-card {
        background-color: rgba(var(--brand-surface-rgb), 0.5);
        border: 1px solid rgba(var(--brand-border-rgb), 0.8);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.5), 0 2px 4px -2px rgba(0, 0, 0, 0.5);
      }

      .text-glow-primary {
        text-shadow: 0 0 10px rgba(99, 102, 241, 0.4);
      }

      .text-glow-cyan {
        text-shadow: 0 0 10px rgba(6, 182, 212, 0.4);
      }

      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }

      .animate-fade-in {
        animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      }

      body {
        background-color: var(--brand-bg);
        color: var(--brand-text);
        font-family: 'Inter', sans-serif;
        min-height: 100vh;
        background-image: 
          radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.03) 0%, transparent 40%),
          radial-gradient(circle at 90% 80%, rgba(6, 182, 212, 0.03) 0%, transparent 40%);
      }

      .dark body {
        background-image: 
          radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.05) 0%, transparent 40%),
          radial-gradient(circle at 90% 80%, rgba(6, 182, 212, 0.05) 0%, transparent 40%);
      }

      /* Dropdown option styles */
      select option {
        background-color: var(--brand-surface);
        color: var(--brand-text);
      }

      /* Custom Scrollbar */
      ::-webkit-scrollbar {
        width: 6px;
        height: 6px;
      }
      ::-webkit-scrollbar-track {
        background-color: var(--brand-bg);
      }
      ::-webkit-scrollbar-thumb {
        background-color: var(--brand-border);
        border-radius: 9999px;
      }
      ::-webkit-scrollbar-thumb:hover {
        background-color: rgba(156, 163, 175, 0.4);
      }
    </style>

</head>
<body class="bg-gray-50 text-gray-800 font-sans antialiased dark:bg-neutral-900 dark:text-gray-200">

<?php if ($isLoggedIn): ?>
    <!-- ========== HEADER ========== -->
    <header class="sticky top-0 inset-x-0 flex flex-wrap sm:justify-start sm:flex-nowrap z-[48] w-full bg-white border-b border-gray-200 text-sm py-2.5 sm:py-4 lg:ps-64 dark:bg-neutral-900 dark:border-neutral-700">
        <nav class="flex basis-full items-center w-full mx-auto px-4 sm:px-6" aria-label="Global">
            <div class="me-5 lg:me-0 lg:hidden">
                <!-- Logo for mobile -->
                <a class="flex-none text-xl font-semibold dark:text-white flex items-center gap-x-2" href="index.php" aria-label="Brand">
                    <div class="inline-flex w-8 h-8 rounded-lg bg-gradient-to-tr from-brand-primary to-brand-secondary items-center justify-center">
                        <i class="fa-solid fa-cube text-white text-sm"></i>
                    </div>
                    <?php echo SITE_NAME; ?>
                </a>
            </div>

            <div class="w-full flex items-center justify-end ms-auto sm:justify-between sm:gap-x-3 sm:order-3">
                <div class="sm:hidden">
                    <button type="button" class="w-[2.375rem] h-[2.375rem] inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700">
                        <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    </button>
                </div>

                <div class="hidden sm:block">
                    <!-- Placeholder to push user menu to right -->
                </div>

                <div class="flex flex-row items-center justify-end gap-2">
                    <div class="flex items-center space-x-3 bg-gray-100 dark:bg-neutral-800 py-1.5 px-3 rounded-full">
                        <span class="text-xs font-bold text-gray-800 dark:text-white"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <div class="w-6 h-6 rounded-full bg-brand-primary flex items-center justify-center text-xs font-bold text-white uppercase">
                            <?php echo substr($_SESSION['username'], 0, 1); ?>
                        </div>
                    </div>
                </div>

                <!-- Navigation Toggle -->
                <button type="button" class="lg:hidden ms-1 w-[2.375rem] h-[2.375rem] inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700" data-hs-overlay="#application-sidebar" aria-controls="application-sidebar" aria-label="Toggle navigation">
                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/></svg>
                </button>
            </div>
        </nav>
    </header>
    <!-- ========== END HEADER ========== -->

    <!-- ========== MAIN CONTENT ========== -->
    <!-- Sidebar -->
    <div id="application-sidebar" class="hs-overlay [--auto-close:lg] hs-overlay-open:translate-x-0 -translate-x-full transition-all duration-300 transform hidden fixed top-0 start-0 bottom-0 z-[60] w-64 bg-white border-e border-gray-200 pt-7 pb-10 overflow-y-auto lg:block lg:translate-x-0 lg:end-auto lg:bottom-0 [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-700 dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500 dark:bg-neutral-900 dark:border-neutral-700">
        <div class="px-6 flex justify-between items-center">
            <!-- Logo Area -->
            <a href="index.php" class="flex items-center space-x-3 group">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-primary to-brand-secondary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform duration-300">
                    <i class="fa-solid fa-cube text-white text-lg"></i>
                </div>
                <div>
                    <h1 class="text-lg font-extrabold tracking-tight bg-gradient-to-r from-brand-primary to-brand-secondary bg-clip-text text-transparent group-hover:opacity-90 transition-opacity"><?php echo SITE_NAME; ?></h1>
                    <p class="text-[10px] text-gray-500 uppercase font-bold tracking-wider dark:text-neutral-500"><?php echo SITE_SUBTITLE; ?></p>
                </div>
            </a>
            <!-- Mobile Close Button -->
            <button type="button" class="lg:hidden w-[2.375rem] h-[2.375rem] inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-full border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-700" data-hs-overlay="#application-sidebar">
                <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
        </div>

        <nav class="hs-accordion-group p-6 w-full flex flex-col flex-wrap" data-hs-accordion-always-open>
            <div class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 dark:text-neutral-500">Menu</div>
            <ul class="space-y-1.5">
                <?php if ($isAdmin): ?>
                    <li>
                        <a href="admin" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'admin.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-chart-line w-4 text-center"></i>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="mods" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo in_array($current_page, ['mods.php', 'add-mod.php', 'upload.php']) ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-gamepad w-4 text-center"></i>
                            Manage Mods
                        </a>
                    </li>
                    <li>
                        <a href="licenses" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo in_array($current_page, ['licenses.php', 'add-license.php']) ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-key w-4 text-center"></i>
                            License Keys
                        </a>
                    </li>
                    <li>
                        <a href="approvals" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'approvals.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-cart-flatbed w-4 text-center"></i>
                            Orders
                        </a>
                    </li>
                    <li>
                        <a href="settings" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'settings.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-sliders w-4 text-center"></i>
                            Settings
                        </a>
                    </li>
                <?php else: ?>
                    <li>
                        <a href="dashboard" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'dashboard.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-house w-4 text-center"></i>
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="keys" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'keys.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                            <i class="fa-solid fa-store w-4 text-center"></i>
                            Store
                        </a>
                    </li>
                <?php endif; ?>
                <li>
                    <a href="docs" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 <?php echo $current_page == 'docs.php' ? 'bg-gray-100 dark:bg-neutral-800 font-semibold text-brand-primary' : 'text-gray-700 dark:text-neutral-400' ?>">
                        <i class="fa-solid fa-book w-4 text-center"></i>
                        API Docs
                    </a>
                </li>
            </ul>

            <div class="mt-8">
                <ul class="space-y-1.5">
                    <li>
                        <a href="logout" class="flex items-center gap-x-3.5 py-2 px-2.5 text-sm rounded-lg text-red-600 hover:bg-red-50 dark:text-red-500 dark:hover:bg-red-800/10">
                            <i class="fa-solid fa-right-from-bracket w-4 text-center"></i>
                            Log Out
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <!-- End Sidebar -->

    <!-- Content -->
    <div class="w-full pt-10 px-4 sm:px-6 md:px-8 lg:ps-72 pb-10">
<?php else: ?>
    <!-- Non-logged in layout -->
    <main class="w-full">
<?php endif; ?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/auth.php';

// Check if user is admin
requireAdmin();

$pdo = getDBConnection();

$success = '';
$error = '';

// Handle Approval/Rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['transaction_id'])) {
        $transactionId = (int)$_POST['transaction_id'];
        $action = $_POST['action'];

        try {
            $pdo->beginTransaction();

            // Get transaction info
            $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending' AND type = 'purchase'");
            $stmt->execute([$transactionId]);
            $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$transaction) {
                throw new Exception("Invalid or already processed transaction.");
            }

            // Extract key ID from reference (format: "License purchase #ID")
            $keyId = (int)str_replace("License purchase #", "", $transaction['reference']);

            if ($action === 'approve') {
                // Mark transaction completed
                $stmt = $pdo->prepare("UPDATE transactions SET status = 'completed' WHERE id = ?");
                $stmt->execute([$transactionId]);

                // Mark key active (set sold_at)
                $stmt = $pdo->prepare("UPDATE license_keys SET sold_at = NOW() WHERE id = ?");
                $stmt->execute([$keyId]);

                $success = "Order #{$transactionId} approved successfully. Key assigned to user.";
            } elseif ($action === 'reject') {
                // Mark transaction failed
                $stmt = $pdo->prepare("UPDATE transactions SET status = 'failed' WHERE id = ?");
                $stmt->execute([$transactionId]);

                // Reset key to available
                $stmt = $pdo->prepare("UPDATE license_keys SET status = 'available', sold_to = NULL WHERE id = ?");
                $stmt->execute([$keyId]);

                $success = "Order #{$transactionId} rejected. Key returned to available pool.";
            }

            $pdo->commit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = $e->getMessage();
        }
    }
}

// Get pending orders
$stmt = $pdo->query("SELECT t.*, u.username, lk.license_key, lk.duration, lk.duration_type, m.name as mod_name 
                    FROM transactions t 
                    JOIN users u ON t.user_id = u.id 
                    JOIN license_keys lk ON CAST(REPLACE(t.reference, 'License purchase #', '') AS UNSIGNED) = lk.id
                    JOIN mods m ON lk.mod_id = m.id
                    WHERE t.status = 'pending' AND t.type = 'purchase'
                    ORDER BY t.created_at DESC");
$pendingOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Pending Orders - " . SITE_NAME;
require_once 'includes/header.php';
?>

<!-- Header -->
<div class="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
    <div>
        <h2 class="text-2xl font-bold tracking-tight text-glow-primary">Pending Orders</h2>
        <p class="text-sm text-brand-muted mt-1">Review and approve UPI payments for keys.</p>
    </div>
</div>

<!-- Alerts -->
<?php if ($success): ?>
    <div class="bg-brand-success/10 border border-brand-success/20 text-brand-success text-xs rounded-xl p-3.5 mb-6 flex items-center space-x-2.5">
        <i class="fa-solid fa-circle-check text-base"></i>
        <span><?php echo htmlspecialchars($success); ?></span>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="bg-brand-error/10 border border-brand-error/20 text-brand-error text-xs rounded-xl p-3.5 mb-6 flex items-center space-x-2.5">
        <i class="fa-solid fa-circle-exclamation text-base"></i>
        <span><?php echo htmlspecialchars($error); ?></span>
    </div>
<?php endif; ?>

<!-- Pending Orders Table -->
<div class="bg-white border border-gray-200 rounded-xl shadow-sm dark:bg-neutral-900 dark:border-neutral-700 rounded-2xl border border-brand-border/60 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-brand-surface/40 border-b border-brand-border/60 text-xs uppercase tracking-wider text-brand-muted">
                    <th class="p-4 font-semibold">User</th>
                    <th class="p-4 font-semibold">Mod & Key</th>
                    <th class="p-4 font-semibold">Amount</th>
                    <th class="p-4 font-semibold">Date</th>
                    <th class="p-4 font-semibold text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-brand-border/30 text-sm">
                <?php if (empty($pendingOrders)): ?>
                <tr>
                    <td colspan="5" class="p-8 text-center text-brand-muted">
                        <i class="fa-solid fa-check-double text-3xl mb-3 opacity-50 block"></i>
                        No pending orders to approve.
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($pendingOrders as $order): ?>
                    <tr class="hover:bg-brand-surface/30 transition-colors">
                        <td class="p-4">
                            <span class="font-semibold text-brand-text"><?php echo htmlspecialchars($order['username']); ?></span>
                        </td>
                        <td class="p-4">
                            <div class="font-bold text-brand-text mb-1"><?php echo htmlspecialchars($order['mod_name']); ?> <span class="text-[10px] bg-brand-primary/10 text-brand-primary px-1.5 py-0.5 rounded ml-1"><?php echo $order['duration'] . ' ' . $order['duration_type']; ?></span></div>
                            <div class="font-mono text-xs text-brand-muted truncate w-48"><?php echo htmlspecialchars($order['license_key']); ?></div>
                        </td>
                        <td class="p-4 font-bold text-brand-success">
                            ₹<?php echo number_format($order['amount'], 2); ?>
                        </td>
                        <td class="p-4 text-xs text-brand-muted">
                            <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?>
                        </td>
                        <td class="p-4 text-right space-x-2">
                            <form method="POST" class="inline-block">
                                <input type="hidden" name="transaction_id" value="<?php echo $order['id']; ?>">
                                <button type="submit" name="action" value="approve" class="px-3 py-1.5 bg-brand-success/20 text-brand-success hover:bg-brand-success/30 rounded-lg text-xs font-bold transition-colors">
                                    <i class="fa-solid fa-check mr-1"></i> Approve
                                </button>
                                <button type="submit" name="action" value="reject" class="px-3 py-1.5 bg-brand-error/20 text-brand-error hover:bg-brand-error/30 rounded-lg text-xs font-bold transition-colors ml-2">
                                    <i class="fa-solid fa-xmark mr-1"></i> Reject
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>